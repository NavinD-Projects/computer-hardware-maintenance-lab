# Computer Hardware, Maintenance and Networking Lab

A beginner-friendly practical learning portfolio covering PC hardware, operating-system maintenance, and basic networking.

> **Portfolio honesty:** This repository is a learning record and lab workbook. Complete each activity on your own device or in a supervised lab, add your own observations, and upload your own screenshots/photos before describing an activity as completed. Do not claim work you have not performed.

## Projects

1. [Computer Hardware Assembly and Troubleshooting](01-hardware-assembly/README.md)
2. [Operating System Installation and Maintenance](02-os-installation-maintenance/README.md)
3. [Basic Computer Networking and Troubleshooting](03-networking-troubleshooting/README.md)

## Suggested tools

- A Windows PC or laptop
- Phillips screwdriver (only if you are authorised and comfortable opening a desktop)
- Windows Device Manager and Disk Management
- Windows Command Prompt
- GitHub for documentation and evidence

## How to use this repository

1. Read the safety notes in each project.
2. Perform the activities only when safe and permitted.
3. Record the date, device details, steps, results, and issues in each project's `LAB-LOG.md`.
4. Add your own evidence to the relevant `evidence/` folder.
5. Update the status below honestly.

## Project status

| Project | Status |
|---|---|
| Hardware assembly and troubleshooting | Not started |
| OS installation and maintenance | Not started |
| Networking and troubleshooting | Not started |

Change a status only after completing and documenting the activity.

## Certifications

- Computer Hardware Basics
- Cyber Security Basics
- Networking Essentials – Naan Mudhalvan

## Skills being practised

Hardware component identification, preventive maintenance, Windows administration basics, driver checks, IP configuration, DNS basics, and network diagnostics.
